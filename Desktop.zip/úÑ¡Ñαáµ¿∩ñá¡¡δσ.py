import random
from google.colab import files

# --- Настройки ---
DB_NAME_PLACEHOLDER = "mgpu_ico_db_13"
OUTPUT_SQL_FILENAME = "populate_restaurant.sql"

# --- Данные для генерации ---
menu_items_data = [
    ('Борщ', 'Супы', 350.00),
    ('Салат Цезарь', 'Салаты', 450.00),
    ('Тирамису', 'Десерты', 380.00),
    ('Чизкейк', 'Десерты', 320.00),
    ('Шоколадный фондан', 'Десерты', 290.00)
]

orders_data = [
    (1, '2024-01-15 12:30:00', 830.00),
    (3, '2024-01-15 13:15:00', 1570.00),
    (2, '2024-01-15 14:00:00', 710.00)
]

# --- Функции для генерации SQL-запросов ---

def generate_create_tables():
    """Генерирует CREATE TABLE запросы."""
    create_scripts = []
    
    create_scripts.append("CREATE TABLE menu_items (")
    create_scripts.append("  item_id INT NOT NULL AUTO_INCREMENT,")
    create_scripts.append("  name VARCHAR(255) NOT NULL,")
    create_scripts.append("  category VARCHAR(255) NOT NULL,")
    create_scripts.append("  price DECIMAL(10, 2) NOT NULL,")
    create_scripts.append("  PRIMARY KEY (item_id)")
    create_scripts.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")
    
    create_scripts.append("\nCREATE TABLE orders (")
    create_scripts.append("  order_id INT NOT NULL AUTO_INCREMENT,")
    create_scripts.append("  table_number INT NOT NULL,")
    create_scripts.append("  order_date DATETIME NOT NULL,")
    create_scripts.append("  total_amount DECIMAL(10, 2) NOT NULL,")
    create_scripts.append("  PRIMARY KEY (order_id)")
    create_scripts.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")
    
    return "\n".join(create_scripts)

def generate_menu_items_insert_statements():
    """Генерирует INSERT запросы для таблицы menu_items."""
    inserts = []
    for item in menu_items_data:
        name, category, price = item
        inserts.append(
            f"INSERT INTO menu_items (name, category, price) VALUES ('{name}', '{category}', {price:.2f});"
        )
    return "\n".join(inserts)

def generate_orders_insert_statements():
    """Генерирует INSERT запросы для таблицы orders."""
    inserts = []
    for order in orders_data:
        table_number, order_date, total_amount = order
        inserts.append(
            f"INSERT INTO orders (table_number, order_date, total_amount) VALUES ({table_number}, '{order_date}', {total_amount:.2f});"
        )
    return "\n".join(inserts)

def generate_select_query():
    """Генерирует SELECT запрос."""
    return "SELECT * \nFROM menu_items \nWHERE category = 'Десерты';"

# --- Основная логика скрипта ---
sql_script_content = []
sql_script_content.append(f"USE {DB_NAME_PLACEHOLDER}")

sql_script_content.append("\n-- Создание таблиц\n")
sql_script_content.append(generate_create_tables())

sql_script_content.append("\n\n-- Заполнение таблицы menu_items\n")
sql_script_content.append(generate_menu_items_insert_statements())

sql_script_content.append("\n\n-- Заполнение таблицы orders\n")
sql_script_content.append(generate_orders_insert_statements())

sql_script_content.append("\n\n-- Пример SELECT запроса\n")
sql_script_content.append(generate_select_query())

final_sql_string = "\n".join(sql_script_content)

# Создание и скачивание файла
with open(OUTPUT_SQL_FILENAME, "w", encoding="utf-8") as f:
    f.write(final_sql_string)

print(f"SQL-скрипт '{OUTPUT_SQL_FILENAME}' успешно сгенерирован.")
print("Сейчас начнется скачивание файла...")

files.download(OUTPUT_SQL_FILENAME)