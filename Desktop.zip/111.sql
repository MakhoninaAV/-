USE mgpu_ico_db_13
CREATE TABLE menu_items (
  item_id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(255) NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  PRIMARY KEY (item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE orders (
  order_id INT NOT NULL AUTO_INCREMENT,
  table_number INT NOT NULL,
  order_date DATETIME NOT NULL,
  total_amount DECIMAL(10, 2) NOT NULL,
  PRIMARY KEY (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO menu_items (name, category, price) VALUES ('Борщ', 'Супы', 350.00);
INSERT INTO menu_items (name, category, price) VALUES ('Салат Цезарь', 'Салаты', 450.00);
INSERT INTO menu_items (name, category, price) VALUES ('Тирамису', 'Десерты', 380.00);
INSERT INTO menu_items (name, category, price) VALUES ('Чизкейк', 'Десерты', 320.00);
INSERT INTO menu_items (name, category, price) VALUES ('Шоколадный фондан', 'Десерты', 290.00);

INSERT INTO orders (table_number, order_date, total_amount) VALUES (1, '2024-01-15 12:30:00', 830.00);
INSERT INTO orders (table_number, order_date, total_amount) VALUES (3, '2024-01-15 13:15:00', 1570.00);
INSERT INTO orders (table_number, order_date, total_amount) VALUES (2, '2024-01-15 14:00:00', 710.00);

SELECT * 
FROM menu_items 
WHERE category = 'Десерты';

SELECT * FROM menu_items;
SELECT * FROM orders;